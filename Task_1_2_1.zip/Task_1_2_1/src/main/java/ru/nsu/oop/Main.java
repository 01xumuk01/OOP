package ru.nsu.oop;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

    }
}