package ru.nsu.oop.graph;

public class Vertex<T> {
    private final String name;
    private final T value;

    public Vertex(String name, T value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return this.name;
    }

    public T getValue() {
        return this.value;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof Vertex<?> vertex)) {
            return false;
        }

        return name.equals(vertex.getName());
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    @Override
    public String toString() {
        return this.name;
    }
}
