package ru.nsu.oop.graph;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.function.Function;

/** Представляет интерфейс графа, который можно реализовать через разные типы связи вершин. */
public interface Graph<T> {
    void addVertex(Vertex<T> vertex);

    void removeVertex(Vertex<T> vertex);

    void addEdge(Vertex<T> vertexFrom, Vertex<T> vertexTo);

    void removeEdge(Vertex<T> vertexFrom, Vertex<T> vertexTo);

    List<Vertex<T>> neighbors(Vertex<T> vertex);

    List<Vertex<T>> topologicalSorting();

    void readFile(Path path, Function<String, T> valueParser) throws IOException;

    List<Vertex<T>> vertices();
}
