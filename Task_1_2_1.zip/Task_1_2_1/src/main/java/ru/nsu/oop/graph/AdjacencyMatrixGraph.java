package ru.nsu.oop.graph;

import java.util.*;

public class AdjacencyMatrixGraph<T> extends AbstractGraph<T> {
    private final List<List<Integer>> adjacencyMatrix;

    public AdjacencyMatrixGraph() {
        this.adjacencyMatrix = new ArrayList<>();
    }

    @Override
    public void addVertex(Vertex<T> vertex) {
        if (list.contains(vertex)) {
            throw new IllegalArgumentException("Вершина уже присутствует в графе");
        }

        list.add(vertex);

        for (List<Integer> row : adjacencyMatrix) {
            row.add(0);
        }

        adjacencyMatrix.add(new ArrayList<>());
        for (int i = 0; i < adjacencyMatrix.size(); i += 1) {
            adjacencyMatrix.get(adjacencyMatrix.size() - 1).add(0);
        }
    }

    @Override
    public void removeVertex(Vertex<T> vertex) {
        int index = list.indexOf(vertex);
        if (index == -1) {
            throw new IllegalArgumentException("Вершина отсутствует в графе");
        }

        for (List<Integer> row : adjacencyMatrix) {
            row.remove(index);
        }

        adjacencyMatrix.remove(index);

        list.remove(vertex);
    }

    @Override
    public void addEdge(Vertex<T> vertexFrom, Vertex<T> vertexTo) {
        int from = vertexIndex(vertexFrom);
        if (from == -1) {
            throw new IllegalArgumentException("Вершина отсутствует в графе");
        }

        int to = vertexIndex(vertexTo);
        if (to == -1) {
            throw new IllegalArgumentException("Вершина отсутствует в графе");
        }

        adjacencyMatrix.get(from).set(to, 1);
    }

    @Override
    public void removeEdge(Vertex<T> vertexFrom, Vertex<T> vertexTo) {
        int from = vertexIndex(vertexFrom);
        if (from == -1) {
            throw new IllegalArgumentException("Вершина отсутствует в графе");
        }

        int to = vertexIndex(vertexTo);
        if (to == -1) {
            throw new IllegalArgumentException("Вершина отсутствует в графе");
        }

        adjacencyMatrix.get(from).set(to, 0);
    }

    @Override
    public List<Vertex<T>> neighbors(Vertex<T> vertex) {
        int index = list.indexOf(vertex);
        if (index == -1) {
            throw new IllegalArgumentException("Вершина отсутствует в графе");
        }

        final List<Vertex<T>> neighbors = new ArrayList<>();

        List<Integer> row = adjacencyMatrix.get(index);

        for (int i = 0; i < row.size(); i++) {
            if (row.get(i) == 1) {
                neighbors.add(list.get(i));
            }
        }

        return neighbors;
    }
}
