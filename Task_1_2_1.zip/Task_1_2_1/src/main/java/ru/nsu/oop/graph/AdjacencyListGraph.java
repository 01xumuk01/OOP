package ru.nsu.oop.graph;

import java.util.*;

public class AdjacencyListGraph<T> extends AbstractGraph<T> {
    private final Map<Vertex<T>, Set<Vertex<T>>> adjacencyList;

    public AdjacencyListGraph() {
        this.adjacencyList = new HashMap<>();
    }

    @Override
    public void addVertex(Vertex<T> vertex) {
        if (list.contains(vertex)) {
            throw new IllegalArgumentException("Вершина уже присутствует в графе");
        }

        list.add(vertex);
        adjacencyList.put(vertex, new HashSet<>());
    }

    @Override
    public void removeVertex(Vertex<T> vertex) {
        vertexIndex(vertex);

        adjacencyList.remove(vertex);

        for (Set<Vertex<T>> neighbors : adjacencyList.values()) {
            neighbors.remove(vertex);
        }

        list.remove(vertex);
    }

    @Override
    public void addEdge(Vertex<T> vertexFrom, Vertex<T> vertexTo) {
        vertexIndex(vertexFrom);
        vertexIndex(vertexTo);

        adjacencyList.get(vertexFrom).add(vertexTo);
    }

    @Override
    public void removeEdge(Vertex<T> vertexFrom, Vertex<T> vertexTo) {
        vertexIndex(vertexFrom);
        vertexIndex(vertexTo);

        adjacencyList.get(vertexFrom).remove(vertexTo);
    }

    @Override
    public List<Vertex<T>> neighbors(Vertex<T> vertex) {
        vertexIndex(vertex);

        return new ArrayList<>(adjacencyList.get(vertex));
    }
}